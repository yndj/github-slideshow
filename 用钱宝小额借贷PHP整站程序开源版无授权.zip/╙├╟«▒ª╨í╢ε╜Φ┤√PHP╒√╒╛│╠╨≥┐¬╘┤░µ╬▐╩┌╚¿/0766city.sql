-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 �?07 �?11 �?03:27
-- 服务器版本: 5.5.53
-- PHP 版本: 5.6.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `0766city`
--

-- --------------------------------------------------------

--
-- 表的结构 `north_admin`
--

CREATE TABLE IF NOT EXISTS `north_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL,
  `password` varchar(48) NOT NULL,
  `gid` int(11) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  `create_time` int(11) NOT NULL DEFAULT '0',
  `login_time` int(11) NOT NULL DEFAULT '0',
  `login_ip` varchar(16) NOT NULL DEFAULT '0.0.0.0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `north_admin`
--

INSERT INTO `north_admin` (`id`, `username`, `password`, `gid`, `status`, `create_time`, `login_time`, `login_ip`) VALUES
(1, 'admin', 'E788E378CDD1F60D6124817EB4CC4DD0D3D494D1', 0, 1, 0, 1531279610, '127.0.0.1');

-- --------------------------------------------------------

--
-- 表的结构 `north_auth_idcard`
--

CREATE TABLE IF NOT EXISTS `north_auth_idcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `name` varchar(8) DEFAULT NULL,
  `idcard` varchar(18) DEFAULT NULL,
  `photo_face` varchar(255) DEFAULT NULL,
  `photo_back` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- 表的结构 `north_auth_info`
--

CREATE TABLE IF NOT EXISTS `north_auth_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `live_city` varchar(255) DEFAULT NULL,
  `live_address` varchar(255) DEFAULT NULL,
  `live_time` varchar(255) DEFAULT NULL,
  `work_industry` varchar(255) DEFAULT NULL,
  `work_posts` varchar(255) DEFAULT NULL,
  `work_name` varchar(255) DEFAULT NULL,
  `work_city` varchar(255) DEFAULT NULL,
  `work_address` varchar(255) DEFAULT NULL,
  `work_tel` varchar(255) DEFAULT NULL,
  `people_relation_1` varchar(255) DEFAULT NULL,
  `people_relation_2` varchar(255) DEFAULT NULL,
  `people_name_1` varchar(255) DEFAULT NULL,
  `people_name_2` varchar(255) DEFAULT NULL,
  `people_tel_1` varchar(255) DEFAULT NULL,
  `people_tel_2` varchar(255) DEFAULT NULL,
  `bank_num` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_city` varchar(255) DEFAULT NULL,
  `bank_phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- 表的结构 `north_auth_mobile`
--

CREATE TABLE IF NOT EXISTS `north_auth_mobile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `refer` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `data` longtext,
  `token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- 表的结构 `north_feedback`
--

CREATE TABLE IF NOT EXISTS `north_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) NOT NULL,
  `content` text,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- 表的结构 `north_loan`
--

CREATE TABLE IF NOT EXISTS `north_loan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `oid` varchar(255) NOT NULL,
  `money` float NOT NULL DEFAULT '0',
  `day` int(11) NOT NULL DEFAULT '0',
  `fee` float NOT NULL DEFAULT '0',
  `bankname` varchar(255) NOT NULL,
  `banknum` varchar(255) NOT NULL,
  `actual` float NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL DEFAULT '0',
  `borrow_status` int(11) DEFAULT '0',
  `review_time` int(11) NOT NULL DEFAULT '0',
  `review_note` varchar(255) DEFAULT NULL,
  `payment_status` int(11) DEFAULT '0',
  `payment_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- 表的结构 `north_menu`
--

CREATE TABLE IF NOT EXISTS `north_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `href` varchar(255) DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '99',
  `status` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- 转存表中的数据 `north_menu`
--

INSERT INTO `north_menu` (`id`, `pid`, `title`, `icon`, `href`, `sort`, `status`) VALUES
(1, 0, '扩展工具', 'fa-cloud normal', NULL, 99, 1),
(25, 9, '会员管理', 'fa-user', 'User/index', 2, 1),
(9, 0, '用户管理', 'fa-group normal', '', 5, 1),
(12, 9, '管理员', 'fa-user-o', 'Admin/index', 3, 1),
(15, 0, '设置', 'fa-cogs normal', '', 1, 1),
(16, 15, '修改密码', 'fa-id-card', 'Setting/modify', 99, 1),
(17, 15, '网站信息', 'fa-home', 'Setting/index', 1, 1),
(19, 1, '配置管理', 'fa-microchip', 'Config/index', 3, 1),
(27, 0, '信息管理', 'fa-info-circle', '', 3, 1),
(28, 27, '问题反馈', 'fa-feed', 'Feed/index', 99, 1),
(29, 0, '借款管理', 'fa-calendar-check-o', '', 4, 1),
(30, 29, '借款列表', 'fa-calendar-minus-o', 'Loan/index', 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `north_smslog`
--

CREATE TABLE IF NOT EXISTS `north_smslog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) DEFAULT 'reg',
  `code` varchar(10) DEFAULT NULL,
  `mobile` varchar(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT '0',
  `check` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `north_smslog`
--

INSERT INTO `north_smslog` (`id`, `type`, `code`, `mobile`, `create_time`, `status`, `check`) VALUES
(11, 'reg', 'U548', '18888888888', 1528132212, 0, 0),
(12, 'reg', 'O216', '18888888888', 1528132301, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `north_user`
--

CREATE TABLE IF NOT EXISTS `north_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  `cid` varchar(20) DEFAULT NULL,
  `quota` int(11) DEFAULT '0',
  `rate` float DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `north_user`
--

INSERT INTO `north_user` (`id`, `mobile`, `password`, `cid`, `quota`, `rate`, `status`) VALUES
(8, '18888888888', 'aecd82d7f8f28062c94e9682781155dc1f1f818f', '6218065160110008', 8000, 0.3, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
