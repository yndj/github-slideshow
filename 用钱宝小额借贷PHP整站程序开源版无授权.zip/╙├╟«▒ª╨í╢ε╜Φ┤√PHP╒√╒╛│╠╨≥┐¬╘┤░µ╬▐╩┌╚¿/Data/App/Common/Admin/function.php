<?php
//获取后台登录用户信息
function nl_get_adminuser(){
    if(!empty($_SESSION['NorthCMS_AdminUser'])){
        $arr = $_SESSION['NorthCMS_AdminUser'];
        if(!empty($arr)){
            return $arr;
        }
        return '';
    }
    return '';
}

//菜单链接中提取MODEL和ACTION
function nl_get_menuinfo($arr){
    if($arr){
        $link = $arr['link'];
        $tmp = explode('?',$link);
        if($tmp[0]){
            $tmp = explode('/',$tmp[0]);
            return array($tmp[0],$tmp[1]);
        }
        return array('','');
    }
    return array('','');
}

