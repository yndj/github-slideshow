<?php

//获取当前用户信息
function getLoginUser(){
	$session_name = nl_get_customConfig('loginsession');
	$arr = session($session_name);
	if($arr){
		preg_match('/([\d]{4})([\d]{4})([\d]{4})([\d]{4})?/',$arr['cid'],$match);
		unset($match[0]);
		$arr['cid'] = implode(' ', $match);
		$arr['rmobile'] = mask_number($arr['mobile'],4);
	}
	$info = empty($arr)?'':$arr;
	return $info;
}

//返回当前用户登录状态
function isLogin(){
	$info = getLoginUser();
	if(empty($info)){
		return false;
	}
	return true;
}

//生成一个订单号
function mackOid(){
	$yCode = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
	$orderSn = $yCode[intval(date('Y')) - 2011] . strtoupper(dechex(date('m'))) . date('d') . substr(time(), -5) . substr(microtime(), 2, 5) . sprintf('%02d', rand(0, 99));
	return $orderSn;
}