<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/2/11 0011
 * Time: 23:30
 *  公共函数库
 */

//对象转数组
function object_to_array($obj){
    $_arr = is_object($obj) ? get_object_vars($obj) :$obj;
    foreach ($_arr as $key=>$val){
        $val = (is_array($val) || is_object($val)) ? object_to_array($val):$val;
        $arr[$key] = $val;
    }
    return $arr;
}

//循环删除目录和文件函数
function delDirAndFile( $dirName ){
    if ( $handle = opendir( "$dirName" ) ) {
        while ( false !== ( $item = readdir( $handle ) ) ) {
            if ( $item != "." && $item != ".." ) {
                if ( is_dir( "$dirName/$item" ) ) {
                    delDirAndFile( "$dirName/$item" );
                } else {
                    unlink( "$dirName/$item");
                }
            }
        }
        closedir( $handle );
        rmdir( $dirName );
    }
}


//获取一个文件夹下文件/文件夹列表
function nl_getFoderlist($dir,$foder = false){
    $arr = array();
    if(is_dir($dir)){
        if($dh = opendir($dir)){
            while(($file = readdir($dh)) != false){
                if($file != "." && $file != ".."){
                    if(!$foder){
                        $arr[] = $file;
                    }else{
                        if(is_dir($dir.$file)){
                            $arr[] = $file;
                        }
                    }
                }
            }
            closedir($dh);
        }
    }
    return $arr;
}


//获取自定义配置内容
function nl_get_customConfig($key){
    if(!$key)
        return '';
    $arr = C('NL_CONFIG_'.$key);
    if(!$arr)
        return '';
    return $arr['value'];
}

/**
 * [nl_writeArr 写入配置文件方法]
 * @param  [type] $arr      [要写入的数据]
 * @param  [type] $filename [文件路径]
 * @return [type]           [description]
 */
function nl_writeArr($arr, $filename) {
    return file_put_contents($filename, "<?php\r\nreturn " . var_export($arr, true) . ";");
}

/**
 * [nl_updateArr 更新配置文件方法]
 * @param  [type] $arr      [要更新的数据]
 * @param  [type] $filename [文件路径]
 * @return [type]           [description]
 */
function nl_updateArr($arr, $filename) {
    $file = include $filename;
    $res = array_merge($file, $arr);
    return nl_writeArr($res,$filename);
}

//判断是否为移动设备访问
function ismobile() {
    // 如果有HTTP_X_WAP_PROFILE则一定是移动设备
    if (isset ($_SERVER['HTTP_X_WAP_PROFILE']))
        return true;
    //此条摘自TPM智能切换模板引擎，适合TPM开发
    if(isset ($_SERVER['HTTP_CLIENT']) &&'PhoneClient'==$_SERVER['HTTP_CLIENT'])
        return true;
    //如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息
    if (isset ($_SERVER['HTTP_VIA']))
        //找不到为flase,否则为true
        return stristr($_SERVER['HTTP_VIA'], 'wap') ? true : false;
    //判断手机发送的客户端标志,兼容性有待提高
    if (isset ($_SERVER['HTTP_USER_AGENT'])) {
        $clientkeywords = array(
            'nokia','sony','ericsson','mot','samsung','htc','sgh','lg','sharp','sie-','philips','panasonic','alcatel','lenovo','iphone','ipod','blackberry','meizu','android','netfront','symbian','ucweb','windowsce','palm','operamini','operamobi','openwave','nexusone','cldc','midp','wap','mobile'
        );
        //从HTTP_USER_AGENT中查找手机浏览器的关键字
        if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
            return true;
        }
    }
    //协议法，因为有可能不准确，放到最后判断
    if (isset ($_SERVER['HTTP_ACCEPT'])) {
        // 如果只支持wml并且不支持html那一定是移动设备
        // 如果支持wml和html但是wml在html之前则是移动设备
        if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))) {
            return true;
        }
    }
    return false;
}

/** 
* QQ号等或手机号中加星号掩码，保护隐私 
* @param    num     $num        QQ号或者手机号 
* @param    num     $star_num   添加星星个个数 
* @return   string              返回添加了星号后的QQ号或者手机号 
* @author   shuiguang  
*/   
function mask_number($num, $star_num = 4)  
{  
    $star_num = $star_num >= strlen($num) ? strlen($num)-2 : (int)$star_num;  
    if($star_num % 2 == 0)  
    {  
        $star_left = $star_right = $star_num/2;  
    }else{  
        $star_left = floor($star_num/2);  
        $star_right = $star_num - $star_left;  
    }  
    $len = strlen($num);  
    $left = floor($len/2)-$star_left;  
    $right = round($len/2)-$star_right;  
    $middle = $len - $left - $right;  
    $result = substr($num, 0, $left).str_repeat("*", $middle).substr($num, $left+$middle, $right);  
    return $result;  
}


//-----------------------------------------------------

//生成纯数字
function getNumStr($lenth = 1){
    $str = '';
    for ($i=0; $i < $lenth; $i++) { 
        $str .= rand(0,9);
    }
    return $str;
}
//加密会员密码
function getPass2User($str = ''){
    return sha1(md5($str));
}
//判断手机号格式
function isMobileNum($num){
    if (!is_numeric($num)){
        return false;
    }
    $t = preg_match('#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,6,7,8]{1}\d{8}$|^18[\d]{9}$#',$num);
    return $t?true:false;
}
/********************php验证身份证号码是否正确函数*********************/
function isIdcard( $id ){ 
      $id = strtoupper($id); 
      $regx = "/(^\d{15}$)|(^\d{17}([0-9]|X)$)/"; 
      $arr_split = array(); 
      if(!preg_match($regx, $id)) 
      { 
        return FALSE; 
      } 
      if(15==strlen($id)) //检查15位 
      { 
        $regx = "/^(\d{6})+(\d{2})+(\d{2})+(\d{2})+(\d{3})$/"; 
        @preg_match($regx, $id, $arr_split); 
		return true;
      } 
      else      //检查18位 
      { 
        $regx = "/^(\d{6})+(\d{4})+(\d{2})+(\d{2})+(\d{3})([0-9]|X)$/"; 
        @preg_match($regx, $id, $arr_split); 
        $dtm_birth = $arr_split[2] . '/' . $arr_split[3]. '/' .$arr_split[4]; 
        if(!strtotime($dtm_birth)) //检查生日日期是否正确 
        { 
          return FALSE; 
        } 
        else
        { 
			return true;
        } 
      } 
} 