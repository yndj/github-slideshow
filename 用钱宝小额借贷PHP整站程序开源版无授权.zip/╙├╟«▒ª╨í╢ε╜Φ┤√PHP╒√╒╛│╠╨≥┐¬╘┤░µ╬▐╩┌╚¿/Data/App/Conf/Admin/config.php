<?php
return array (
  'DEFAULT_THEME' => 'default',
  'HOME_THEME' => 'default',
);