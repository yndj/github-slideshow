<?php
return array(
    //基础配置部分
    'APP_GROUP_LIST'            =>          'Home,Admin,Public,Agent',
    'DEFAULT_APP'               =>          'Home',
    'TMPL_ACTION_ERROR'         =>          SITE_PATH.'Data/Skin/error.html',
    'TMPL_ACTION_SUCCESS'       =>          SITE_PATH.'Data/Skin/success.html',
    //其他配置部分
    'LOAD_EXT_CONFIG'           =>          'db,url,debug,site,upload,route,other',
    'TAGLIB_LOAD'               =>          true,
    'APP_AUTOLOAD_PATH'         =>          '@.TagLib',
    'TAGLIB_PRE_LOAD'           =>          'NL',
    'TMPL_PARSE_STRING'         =>          array(
                                                 '__UPLOAD__' => __ROOT__.'/Upload',
                                            )

);
?>