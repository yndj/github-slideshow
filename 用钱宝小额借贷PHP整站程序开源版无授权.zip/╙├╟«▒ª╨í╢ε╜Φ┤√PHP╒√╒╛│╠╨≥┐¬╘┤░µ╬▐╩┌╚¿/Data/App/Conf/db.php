<?php
return array(
        'DB_TYPE'   => 'mysql',
        'DB_HOST'   => 'localhost',
        'DB_NAME'   => '0766city',
        'DB_USER'   => 'root',
        'DB_PWD'    => '111',
        'DB_PORT'   => 3306,
        'DB_PREFIX' => 'north_',
        'auth_code' => 'Ga29_f~*au',
);