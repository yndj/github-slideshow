<?php
return array (
  'NL_CONFIG_smsuser' => 
  array (
    'name' => '短信帐号',
    'value' => '',
    'remark' => '短信宝用户名',
  ),
  'NL_CONFIG_smspass' => 
  array (
    'name' => '短信密码',
    'value' => '',
    'remark' => '短信宝密码',
  ),
  'NL_CONFIG_loginsession' => 
  array (
    'name' => '前台用户SESSION',
    'value' => 'NorthHomeUser',
    'remark' => '一般情况请勿修改',
  ),
  'NL_CONFIG_smsdcount' => 
  array (
    'name' => '短信日限额',
    'value' => '4',
    'remark' => '限制每天同号码发送短信次数,一般运营商会限制4条',
  ),
  'NL_CONFIG_regsmstpl' => 
  array (
    'name' => '会员注册短信模板',
    'value' => '【NorthLove】您的验证码为{code},请在30分钟内输入!',
    'remark' => '',
  ),
  'NL_CONFIG_userquota' => 
  array (
    'name' => '用户注册初始额度',
    'value' => '1000',
    'remark' => '用户注册后默认信用额度',
  ),
  'NL_CONFIG_findpasstpl' => 
  array (
    'name' => '找回密码短信模板',
    'value' => '【NorthLove】您正在找回密码，验证码为{code}。请在30分钟内输入！',
    'remark' => '',
  ),
  'NL_CONFIG_limu_apiKey' => 
  array (
    'name' => '立木征信apiKey',
    'value' => '',
    'remark' => '',
  ),
  'NL_CONFIG_limu_Secret' => 
  array (
    'name' => '立木征信Secret',
    'value' => '',
    'remark' => '',
  ),
  'NL_CONFIG_min_money' => 
  array (
    'name' => '借款最小金额',
    'value' => '500',
    'remark' => '',
  ),
  'NL_CONFIG_step_money' => 
  array (
    'name' => '借款跨度',
    'value' => '100',
    'remark' => '',
  ),
  'NL_CONFIG_min_day' => 
  array (
    'name' => '借款最短时间',
    'value' => '5',
    'remark' => '',
  ),
  'NL_CONFIG_max_day' => 
  array (
    'name' => '借款最长时间',
    'value' => '14',
    'remark' => '',
  ),
  'NL_CONFIG_userrate' => 
  array (
    'name' => '用户注册初始费率',
    'value' => '0.3',
    'remark' => '',
  ),
);