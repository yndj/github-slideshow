<?php
return array (
  'test' => 'Admin/Public/test',
  'agent' => 'Agent/Index/index',
);