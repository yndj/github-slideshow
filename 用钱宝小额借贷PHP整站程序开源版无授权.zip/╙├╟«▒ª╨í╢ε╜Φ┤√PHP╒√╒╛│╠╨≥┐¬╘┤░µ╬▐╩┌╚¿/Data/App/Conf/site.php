<?php
return array (
  'site_name' => '用钱宝',
  'site_url' => 'http://www.0766city.com/',
  'site_title' => '用钱宝',
  'site_logo' => 'https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=2051331214,2851091042&amp;fm=58',
  'site_keywords' => '',
  'site_description' => '',
  'site_icp' => '陕ICP备88888888号',
  'site_code' => '',
  'site_copyright' => '',
);