<?php
return array (
  'upload_extensions' => 'jpg,png,gif,zip,rar',
  'upload_maxsize' => '2048',
);