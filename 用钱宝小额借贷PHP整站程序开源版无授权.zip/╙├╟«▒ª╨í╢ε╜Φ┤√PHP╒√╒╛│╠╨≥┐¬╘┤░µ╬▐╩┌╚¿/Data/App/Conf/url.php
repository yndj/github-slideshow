<?php
return array (
  'URL_MODEL' => '2',
  'TMPL_TEMPLATE_SUFFIX' => '.html',
  'URL_ROUTER_ON' => 'true',
);