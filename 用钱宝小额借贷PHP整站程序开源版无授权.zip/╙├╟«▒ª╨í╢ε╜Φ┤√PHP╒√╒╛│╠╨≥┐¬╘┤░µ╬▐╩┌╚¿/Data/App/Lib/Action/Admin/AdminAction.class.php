<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/2/10 0010
 * Time: 21:59
 *  后台管理员控制器
 */
class AdminAction extends PublicAction{

    /*
     *  管理员列表
     * */
    public function index(){
        $admin_model = D("Admin");
        $lists = $admin_model->order("id")->select();
        $this->assign('lists',$lists);
        $group['0'] = "超级管理员";
		$group['1'] = "管理员";
        $this->assign('group',$group);
        $this->display();
    }

    /*
     *  禁用/启用管理员
     * */
    public function change(){
        $id=I("get.id",0,'intval');
        if(!$id){
            $this->error("参数有误!");
        }
        $c_status=I("get.status",0,'intval');
        $admin_model = D("Admin");
        $status=$admin_model->where(array('id'=>$id,'gid'=>array('neq','0')))->save(array('status'=>$c_status));
        if(!$status){
            $this->error("操作失败!");
        }
        if($c_status){
            $this->success("启用管理员成功!");
        }
        $this->success("禁用管理员成功!");
    }

    /*
     *  删除管理员
     * */
    public function del(){
        $id = I("get.id",0,'intval');
        if(!$id){
            $this->error("参数有误!");
        }
        $status=M("Admin")->where(array('id'=>$id,'gid'=>array('neq','0')))->delete();
        if(!$status){
            $this->error("操作失败!");
        }
        $this->success("删除管理员成功!");
    }

    /*
     *  添加管理员
     * */
    public function add(){
        $admin_model = D("Admin");
        if(IS_POST){
            $username = I("post.username",'','trim');
            $password = I("post.password",'','trim');
            $repassword = I("post.repassword",'','trim');
            $gid = I("post.gid",0,'intval');
            if(!$username){
                $this->error("登录用户名不能为空!");
            }
            if(strlen($username) < 6 || strlen($username) > 12){
                $this->error("用户名长度必须为 6 - 12 位!");
            }
            if(!$password){
                $this->error("登录密码不能为空!");
            }
            if(strlen($password) < 6 || strlen($password) > 18){
                $this->error("密码长度必须为 6 - 18 位!");
            }
            if($password !== $repassword){
                $this->error("两次密码输入不一致!");
            }
            if(!$gid){
                $this->error("请选择用户权限组!");
            }
            $password = $admin_model->getPass($password);
            $r = $admin_model->where(array('username'=>$username))->count();
            if($r){
                $this->error("该用户名已存在!");
            }
            $status = $admin_model->add(array(
                'username'=>$username,
                'password'=>$password,
                'gid'=>$gid,
                'status'=>I("post.status",1,'intval'),
                'create_time'=>time(),
                'login_time'=>0,
                'login_ip'=>'0.0.0.0'
            ));
            if(!$status){
                $this->error("添加失败!");
            }
            $this->success("添加管理员成功!",U('Admin/index'));
        }
        $this->display();
    }

    /*
     *  编辑管理员信息
     * */
    public function edit(){
        $id=I("get.id",0,'intval');
        if(!$id){
            $this->error("参数有误!");
        }
        $admin_model = D("Admin");
        $info = $admin_model->where(array('id'=>$id))->find();
        if($info && $info['gid'] == 0){
            $this->error("不允许修改创始人信息!");
        }
        if(IS_POST){
            $username = I("post.username",'','trim');
            $password = I("post.password",'','trim');
            $repassword = I("post.repassword",'','trim');
            $gid = I("post.gid",0,'intval');
            if(!$username){
                $this->error("登录用户名不能为空!");
            }
            if(strlen($username) < 6 || strlen($username) > 12){
                $this->error("用户名长度必须为 6 - 12 位!");
            }
            if(!$gid){
                $this->error("请选择用户权限组!");
            }
            $r = $admin_model->where(array('username'=>$username))->find();
            if($r && $r['id'] != $id){
                $this->error("该用户名已存在!");
            }
            $arr = array(
                'username'=>$username,
                'gid'=>$gid,
                'status'=>I("post.status",1,'intval')
            );
            if($password){
                if(strlen($password) < 6 || strlen($password) > 18){
                    $this->error("密码长度必须为 6 - 18 位!");
                }
                if($password !== $repassword){
                    $this->error("两次密码输入不一致!");
                }
                $password = $admin_model->getPass($password);
                $arr['password'] = $password;
            }
            $status = $admin_model->where(array('id'=>$id))->save($arr);
            if(!$status){
                $this->error("编辑失败!");
            }
            $this->success("编辑管理员成功!",U('Admin/index'));
        }
        if(!$info){
            $this->error("不存在该管理员信息!");
        }
        $this->assign('data',$info);
        $this->display();
    }





}