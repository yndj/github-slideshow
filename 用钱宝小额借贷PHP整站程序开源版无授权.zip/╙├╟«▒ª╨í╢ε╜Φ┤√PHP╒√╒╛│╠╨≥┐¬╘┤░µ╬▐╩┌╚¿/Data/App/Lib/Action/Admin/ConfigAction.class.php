<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/2/11 0011
 * Time: 22:39
 *  后台自定义配置控制器
 */

class ConfigAction extends PublicAction{

    /*
     *  配置列表
     * */
    public function index(){
        //读取配置
        $config = include CONF_PATH.'other.php';
        if(empty($config))
            $config = array();
        $this->assign('lists',$config);
        $this->display();
    }

    /*
     *  添加配置
     * */
    public function add(){
        if(IS_POST){
            $name=I("post.name",'','trim');
            $value=I("post.value",'','trim');
            $key=I("post.key",'','trim');
            $remark=I("post.remark",'','trim');
            if(!$name || !$key){
                $this->error("配置名称和键值不能留空!");
            }
            $tmp = C('NL_CONFIG_'.$key);
            if(!empty($tmp)){
                $this->error("配置键值重复!");
            }
            $arr = array(
                'NL_CONFIG_'.$key  =>  array(
                    'name'  =>  htmlspecialchars($name),
                    'value' =>  htmlspecialchars($value),
                    'remark'=>  htmlspecialchars($remark)
                )
            );
            if(!nl_updateArr($arr,CONF_PATH.'other.php')){
                $this->error('添加配置失败','',true);
            }
            $this->success("添加配置成功!");
        }
        $this->display();
    }

    /*
     *  编辑自定义配置
     * */
    public function edit($key=''){
        if(!$key){
            $this->error("参数错误!");
        }
        $tmp = C('NL_CONFIG_'.$key);
        if(empty($tmp)){
            $this->error("不存在该配置!");
        }
        if(IS_POST){
            $name=I("post.name",'','trim');
            $value=I("post.value",'','trim');
            $remark=I("post.remark",'','trim');
            if(!$name){
                $this->error("配置名称不能留空!");
            }
            $arr = array(
                'NL_CONFIG_'.$key  =>  array(
                    'name'  =>  htmlspecialchars($name),
                    'value' =>  htmlspecialchars($value),
                    'remark'=>  htmlspecialchars($remark)
                )
            );
            if(!nl_updateArr($arr,CONF_PATH.'other.php')){
                $this->error('编辑配置失败','',true);
            }
            $this->success("编辑配置成功!",U('Config/index'));
        }
        $this->assign("data",$tmp);
        $this->assign("key",$key);
        $this->display();
    }

    /*
     *  删除自定义配置
     * */
    public function del($key=''){
        if(!$key){
            $this->error("参数错误!");
        }
        $tmp = C('NL_CONFIG_'.$key);
        if(empty($tmp)){
            $this->error("不存在该配置!");
        }
        unset($tmp);
        $arr = include CONF_PATH.'other.php';
        $newarr = array();
        foreach($arr as $akey=>$aval){
            if($akey != 'NL_CONFIG_'.$key){
                $newarr[$akey] = $aval;
            }
        }
        unset($arr);
        if(!nl_writeArr($newarr,CONF_PATH.'other.php')){
            $this->error('删除配置失败','',true);
        }
        $this->success("删除配置成功!",U('Config/index'));
    }


}