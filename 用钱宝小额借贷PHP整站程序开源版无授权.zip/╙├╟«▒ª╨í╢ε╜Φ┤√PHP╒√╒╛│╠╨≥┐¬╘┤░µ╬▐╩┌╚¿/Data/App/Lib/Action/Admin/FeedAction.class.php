<?php
class FeedAction extends PublicAction{

	//反馈信息列表
	public function index(){
        $limits = 30;
        $feed_model = D("Feedback");
        import('ORG.Util.Page');
        $count= $feed_model->count();
        $Page = new Page($count,$limits);
        $allpage = intval(ceil($count / $limits));
        $nowpage = I('get.p', 1, 'intval');
        $show = $Page->show();
        $feed = $feed_model->order('id Desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign("lists",$feed);
        $this->assign("page",$show);
        $this -> assign('allpage', $allpage);
        $this -> assign('nowpage', $nowpage);
        $this->display();
	}

	//删除信息
	public function delFeed($id=0){
		if(!$id){
			$this->error("参数错误!");
		}
		$feed_model = D("Feedback");
		$status=$feed_model->where(array('id'=>$id))->delete();
		if(!$status){
			$this->error("删除信息失败!");
		}
		$this->success("操作成功!");
	}


}