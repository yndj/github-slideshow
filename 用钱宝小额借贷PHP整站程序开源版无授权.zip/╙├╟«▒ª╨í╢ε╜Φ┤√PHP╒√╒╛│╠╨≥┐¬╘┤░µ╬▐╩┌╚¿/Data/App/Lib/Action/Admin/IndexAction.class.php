<?php
/**
 * Created by PhpStorm.
 * User: NorthLove
 * Date: 2017/2/9 0009
 * Time: 17:03
 * 后台首页控制器
 */
class IndexAction extends PublicAction{

    /*
     *  后台面板
     * */
    public function index(){
        $this->assign('menu',$this->getMenu());
        $this->display();
    }

    /*
     *  后台控制面板
     * */
    public function main(){
        $this->mysql_version = $this->_mysql_version();
        $this->mysql_size = $this->_mysql_db_size();

        $this->display();
    }

    /*
     *  清除缓存
     * */
    public function delcha(){
        delDirAndFile(RUNTIME_PATH);
        $this->success("清理缓存成功!",U('Index/index'),2);
    }

    /*
     *  生成当前用户权限内的菜单
     * */
    private function getMenu(){
        $uinfo = nl_get_adminuser();
        $menu_model = D("Menu");
        //获取菜单列表
        $menu = $menu_model->getMenu($uinfo['gid'],true);
        $menu = json_encode($menu);
        return $menu;
    }

    private function _mysql_version()
    {
        $Model = new Model();
        $version = $Model->query("select version() as ver");
        return $version[0]['ver'];
    }
    private function _mysql_db_size()
    {
        $Model = new Model();
        $sql = "SHOW TABLE STATUS FROM ".C('DB_NAME');
        $tblPrefix = C('DB_PREFIX');
        if($tblPrefix != null) {
            $sql .= " LIKE '{$tblPrefix}%'";
        }
        $row = $Model->query($sql);
        $size = 0;
        foreach($row as $value) {
            $size += $value["Data_length"] + $value["Index_length"];
        }
        return round(($size/1048576),2).'M';
    }


}