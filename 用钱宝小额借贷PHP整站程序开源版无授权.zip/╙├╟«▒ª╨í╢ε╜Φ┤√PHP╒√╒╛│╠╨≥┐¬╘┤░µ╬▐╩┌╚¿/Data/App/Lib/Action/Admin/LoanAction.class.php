<?php

//	借款管理控制器

class LoanAction extends PublicAction{

    //借款列表
    public function index(){
        $limits = 30;
        $loan_model = D("Loan");
        import('ORG.Util.Page');
        $count= $loan_model->count();
        $Page = new Page($count,$limits);
        $allpage = intval(ceil($count / $limits));
        $nowpage = I('get.p', 1, 'intval');
        $show = $Page->show();
        $DB_PREFIX = C('DB_PREFIX');
        $loan = $loan_model
        		->order('id Desc')
        		->join("{$DB_PREFIX}user on {$DB_PREFIX}loan.uid = {$DB_PREFIX}user.id")
        		->join("{$DB_PREFIX}auth_idcard on {$DB_PREFIX}loan.uid = {$DB_PREFIX}auth_idcard.uid")
        		->join("{$DB_PREFIX}auth_info on {$DB_PREFIX}loan.uid = {$DB_PREFIX}auth_info.uid")
        		->field("{$DB_PREFIX}user.mobile as phone,{$DB_PREFIX}loan.*,{$DB_PREFIX}auth_idcard.name,{$DB_PREFIX}auth_info.bank_num,{$DB_PREFIX}auth_info.bank_name")
        		->limit($Page->firstRow.','.$Page->listRows)
        		->select();
        $this->assign("lists",$loan);
        $this->assign("page",$show);
        $this -> assign('allpage', $allpage);
        $this -> assign('nowpage', $nowpage);
        $this->display();
    }

    //删除订单
    public function delLoan($id = 0){
    	if(!$id){
    		$this->error("参数错误!");
    	}
    	$loan_model = D("Loan");
    	$status = $loan_model->where(array('id'=>$id))->delete();
    	if(!$status){
    		$this->error("操作失败!");
    	}
    	$this->success("删除订单成功!");
    }

    //订单审核
    public function resetStatus(){
    	$id = I("post.id",0,'intval');
    	$borrow_status = I("post.borrow_status",0,'intval');
    	$review_note = I("post.review_note",'');
    	if(!$id){
    		$this->error("参数错误!");
    	}
    	$loan_model = D("Loan");
    	if(!$borrow_status){
    		$this->error("请选择审核结果!");
    	}
        $i = $loan_model->where(array('id'=>$id))->find();
        if(!$i)
            $this->error("订单不存在!");
    	$status = $loan_model
    				->where(array('id'=>$id))
    				->save(array('borrow_status'=>$borrow_status,'review_note'=>$review_note,'review_time'=>time() ));
        if($borrow_status == '1'){
            //借款成功,为代理商分配提成
            $user_model=D("User");
            $agent_model = D("Agent");
            $record_model = D("Agent_record");
            $u = $user_model->where(array('id'=>$i['uid']))->find();
            $u_aid = $u['aid'];//用户所属代理ID
            $a = $agent_model->where(array('id'=>$u_aid))->find();
            if($a){
                if($a['level'] == 1){
                    //所属省级代理,直接分配款项
                    $to_money = ($i['fee'] * $a['rate']) / 100;
                    $to_money = sprintf("%.2f",substr(sprintf("%.3f", $to_money), 0, -1));
                    $newMoney = $a['money'] + $to_money;
                    $arr = array(
                        'aid'       =>  $a['id'],
                        'money_old' =>  $a['money'],
                        'change_money'=>$to_money,
                        'money_after'=> $newMoney,
                        'type'      =>  1,
                        'note'      =>  '用户:'.$u['mobile'].'账单提成',
                        'create_time'=> time()
                    );
                    $record_model->add($arr);
                    $agent_model->where(array('id'=>$u_aid))->save(array('money'=>$newMoney));
                }elseif($a['level'] == 2){
                    //所属市级代理,先分配给其省级代理
                    $f_a = $agent_model->where(array('id'=>$a['pid']))->find();
                    if($f_a){
                        $to_money = ($i['fee'] * $f_a['rate']) / 100;
                        $to_money = sprintf("%.2f",substr(sprintf("%.3f", $to_money), 0, -1));
                        $newMoney = $f_a['money'] + $to_money;
                        $arr = array(
                            'aid'       =>  $f_a['id'],
                            'money_old' =>  $f_a['money'],
                            'change_money'=>$to_money,
                            'money_after'=> $newMoney,
                            'type'      =>  1,
                            'note'      =>  '用户:'.$u['mobile'].'账单提成',
                            'create_time'=> time()
                        );
                        $record_model->add($arr);
                        $agent_model->where(array('id'=>$f_a['id']))->save(array('money'=>$newMoney));
                        //直属代理分配款项
                        $to_money = ($arr['change_money'] * $a['rate']) / 100;
                        $to_money = sprintf("%.2f",substr(sprintf("%.3f", $to_money), 0, -1));
                        $newMoney = $a['money'] + $to_money;
                        $arr = array(
                            'aid'       =>  $a['id'],
                            'money_old' =>  $a['money'],
                            'change_money'=>$to_money,
                            'money_after'=> $newMoney,
                            'type'      =>  1,
                            'note'      =>  '用户:'.$u['mobile'].'账单提成',
                            'create_time'=> time()
                        );
                        $record_model->add($arr);
                        $agent_model->where(array('id'=>$a['id']))->save(array('money'=>$newMoney));
                    }
                }
                /*后期可能增加多级代理*/
            }
        }
    	if(!$status){
    		$this->error("操作失败!");
    	}
    	$this->success("订单审核成功!");
    }


}