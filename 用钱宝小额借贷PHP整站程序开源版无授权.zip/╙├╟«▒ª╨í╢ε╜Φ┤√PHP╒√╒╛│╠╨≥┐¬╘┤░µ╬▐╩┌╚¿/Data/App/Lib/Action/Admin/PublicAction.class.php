<?php
/**
 * Created by PhpStorm.
 * User: NorthLove
 * Date: 2017/2/9 0009
 * Time: 17:12
 * 后台公共类控制器
 */

class PublicAction extends Action{
    /*
     *  后台公共验证
     * */
    public function _initialize(){

//        if(empty($_SESSION['LOGIN_AUTH']) || $_SESSION['LOGIN_AUTH'] != md5('A8_t^a9uI-+?2') ){
 //           $this->error("请从合法的后台1地址进入!",U('Home/Index/index'));
 //       }
        if( MODULE_NAME != "Public" && !$this->is_Login()) {
            $this->error("您还没有登录,请先登录!", U('Public/login'), 3);
        }
        //其他操作
        /*
         *
         *
         * */
    }


    /*
     *  用户注销
     * */
    public function lock(){
        $this->set_Login(null);
        $this->success("您已成功退出登录!",U('Public/login'),3);
    }


    /*
     *  验证后台用户是否登录
     * */
    protected function is_Login(){
        $arr = session('NorthCMS_AdminUser');
        if(empty($arr))
            return false;
        else
            return true;
    }

    /*
     *  设置当前登录用户
     * */
    protected function set_Login($arr = ''){
        if(!empty($arr)){
            $group_model = D("Group");
            $group = $group_model->where(array('id'=>$arr['gid']))->find();
            //保存登录时间及IP
            M("Admin")->where(array('id'=>$arr['id']))->save(array('login_time'=>time(),'login_ip'=>get_client_ip() ));
            unset($arr['password']);
            session('NorthCMS_AdminUser',$arr);
        }else{
            session('NorthCMS_AdminUser',null);
        }
    }

    /*
     *  后台登录
     * */
    public function login(){
        if($this->is_Login()){
            $this->redirect('Index/index',array(),0);exit;
        }
        if(IS_POST){
            $username = I("post.username",'','trim');
            $password = I("post.password",'','trim');
            $verify   = I("post.verify",  '','trim');
            if(!$username || !$password){
                $this->error("用户名和密码不能为空!");
            }
            if(!$verify){
                $this->error("验证码不能为空!");
            }
            if($_SESSION['verify'] != md5(strtoupper($verify))){
                $this->error("验证码输入有误!");
            }
            $admin_model = D("Admin");
            $info=$admin_model->where(array(
                'username'=>$username,
                'password'=>$admin_model->getPass($password)
            ))->find();
            if(!$info){
                $this->error("用户名或密码输入有误!");
            }
            if($info['status'] != 1){
                $this->error("您的帐号已被禁用,请联系管理员!");
            }
            $this->set_Login($info);
            $this->success("登录成功!",U('Index/index'),2);
            exit;
        }
        $this->display();
    }

    /*
     *  后台验证码
     * */
    public function verify(){
        import('ORG.Util.Image');
        Image::buildImageVerify(4,1,'png');
    }


    /*
     *  测试用
     * */
    public function test(){
        //echo U('Admin/Public/test');
    }


}