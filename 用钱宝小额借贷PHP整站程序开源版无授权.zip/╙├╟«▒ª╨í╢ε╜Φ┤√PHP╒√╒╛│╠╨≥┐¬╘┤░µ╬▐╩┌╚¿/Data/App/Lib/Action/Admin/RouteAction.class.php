<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/2/12 0012
 * Time: 1:10
 *  URL美化/路由控制器
 */
class RouteAction extends PublicAction{

    /*
     *  路由列表
     * */
    public function index(){
        $route_model = M("route");
        if(IS_POST){
            //更新排序
            $sort = I("post.sort");
            foreach($sort as $key => $val){
                $route_model->where(array('id'=>$key))->save(array('sort'=>$val));
            }
        }
        $lists=$route_model->order("sort")->select();
        $this->assign('lists',$lists);
        $this->display();
    }

    /*
     *  添加规则
     * */
    public function add(){
        $route_model = M("route");
        if(IS_POST){
            $name=I("post.name",'','trim');
            $raw = I("post.raw",'','trim');
            $display=I("post.display",'','trim');
            $sort=I("post.sort",99,'intval');
            $status=I("post.status",0,'intval');
            if(!$name){
                $this->error("美化规则名称不能为空!");
            }
            if(!$raw){
                $this->error("原始网址不能为空!");
            }
            if(!$display){
                $this->error("显示网址不能为空!");
            }
            $_POST['sort'] = $sort;
            $_POST['status'] = $status;
            $r = $route_model->where(array('raw'=>$raw,'display'=>$display))->count();
            if($r){
                $this->error("同样的规则已经存在!");
            }
            $status=$route_model->add($_POST);
            if(!$status){
                $this->error("操作失败!");
            }
            $this->success("添加规则成功!");
        }
        $this->display();
    }

    /*
     *  编辑规则
     * */
    public function edit($id=0){
        if(!$id){
            $this->error("参数错误!");
        }
        $route_model = M("route");
        if(IS_POST){
            $name=I("post.name",'','trim');
            $raw = I("post.raw",'','trim');
            $display=I("post.display",'','trim');
            $sort=I("post.sort",99,'intval');
            $status=I("post.status",0,'intval');
            if(!$name){
                $this->error("美化规则名称不能为空!");
            }
            if(!$raw){
                $this->error("原始网址不能为空!");
            }
            if(!$display){
                $this->error("显示网址不能为空!");
            }
            $_POST['sort'] = $sort;
            $_POST['status'] = $status;
            $r = $route_model->where(array('raw'=>$raw,'display'=>$display))->find();
            if($r && $r['id'] != $id){
                $this->error("同样的规则已经存在!");
            }
            $status=$route_model->where(array('id'=>$id))->save($_POST);
            if(!$status){
                $this->error("操作失败!");
            }
            $this->success("编辑规则成功!");
        }
        $data = $route_model->where(array('id'=>$id))->find();
        if(!$data){
            $this->error("不存在的路由规则!");
        }
        $this->assign('data',$data);
        $this->display();
    }

    /*
     *  删除路由规则
     * */
    public function del($id=0){
        if(!$id){
            $this->error("参数错误!");
        }
        $route_model = M("route");
        $status=$route_model->where(array('id'=>$id))->delete();
        if(!$status){
            $this->error("操作失败!");
        }
        $this->success("删除规则成功!");
    }

    /*
     *  更新路由配置
     * */
    public function update(){
        $route_model = M("route");
        $arr = $route_model->where(array('status'=>1))->order("sort")->select();
        if(!$arr)
            $arr = array();
        $route = array();
        foreach($arr as $val){
            $route[$val['display']] = $val['raw'];
        }
        //保存路由配置
        if(!nl_writeArr($route,CONF_PATH.'route.php')){
            $this->error('更新路由配置失败');
        }
        $this->success("更新规则成功!",U('Route/index'));
    }



}