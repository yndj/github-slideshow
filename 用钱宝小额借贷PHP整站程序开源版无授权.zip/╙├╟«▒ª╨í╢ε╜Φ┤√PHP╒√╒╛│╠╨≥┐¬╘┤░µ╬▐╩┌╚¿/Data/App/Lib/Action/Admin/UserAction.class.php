<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/3/10 0010
 * Time: 20:35
 *  后台会员管理控制器
 */

class UserAction extends PublicAction{

    //会员列表
    public function index(){
        $limits = 30;
        $user_model = D("User");
        $where=array('mobile'=>'','status'=>'-1');
        if(IS_POST){
            //条件查找
            $mobile = I('post.mobile');
            if(!empty($mobile)){
                $where['seach_mobile'] = $username;
                $where['mobile'] = $mobile;
            }
            $status = I('post.status','-1');
            if($status != '-1')
                $where['status'] = $status;
        }
        $this->where = $where;
        if(!$where['mobile'])
            unset($where['mobile']);
        if($where['status'] == '-1')
            unset($where['status']);
        import('ORG.Util.Page');
        $count= $user_model->where($where)->count();
        $Page = new Page($count,$limits);
        $allpage = intval(ceil($count / $limits));
        $nowpage = I('get.p', 1, 'intval');
        $show = $Page->show();
        $DB_PREFIX = C('DB_PREFIX');
        $user = $user_model
                ->where($where)
                ->order('id Desc')
                ->limit($Page->firstRow.','.$Page->listRows)
                ->select();
        $loan_model = D("Loan");
        for ($i=0; $i < count($user); $i++) {
            $n = $loan_model->where(array('uid'=>$user[$i]['id'],'borrow_status'=>1))->count();
            $user[$i]['borrow'] = $n;
            $n = $loan_model->where(array('uid'=>$user[$i]['id'],'borrow_status'=>2))->count();
            $user[$i]['fborrow'] = $n;
            $n = $loan_model->where(array('uid'=>$user[$i]['id'],'payment_status'=>1))->count();
            $user[$i]['payment'] = $n;
        }
        $this->assign("lists",$user);
        $this->assign("page",$show);
        $this->assign('allpage', $allpage);
        $this->assign('nowpage', $nowpage);
        $this->display();
    }

    //重置密码
    public function resetPass($id = 0){
        if(!$id){
            $this->error("参数错误");
        }
        $user_model = D("User");
        $newPass = getNumStr(6);
        $status = $user_model->where($id)->save(array('password'=>getPass2User($newPass) ));
        if(!$status){
            $this->error("操作失败");
        }
        $this->success($newPass);
    }

    //修改状态
    function resetStatus($id=0,$status=1){
        if(!$id){
            $this->error("参数错误");
        }
        $user_model = D("User");
        $status = $user_model->where($id)->save(array('status'=>$status));
        if(!$status){
            $this->error("操作失败");
        }
        $this->success("操作成功");
    }

    //删除会员
    function delUser($id=0){
        if(!$id){
            $this->error("参数错误");
        }
        $user_model = D("User");
        $status = $user_model->where($id)->delete();
        if(!$status){
            $this->error("操作失败");
        }
        $this->success("操作成功");
    }

    //用户ID查询用户认证信息
    public function viewAuth($id = 0){
        $id = intval($id);
        if(!$id){
            $this->error("参数错误!");
        }
        $user_model = D("User");
        $DB_PREFIX = C('DB_PREFIX');
        $authInfo=$user_model
                  ->where(array("{$DB_PREFIX}user.id"=>$id))
                  ->join("{$DB_PREFIX}auth_idcard on {$DB_PREFIX}user.id = {$DB_PREFIX}auth_idcard.uid")
                  ->join("{$DB_PREFIX}auth_mobile on {$DB_PREFIX}user.id = {$DB_PREFIX}auth_mobile.uid")
                  ->join("{$DB_PREFIX}auth_info on {$DB_PREFIX}user.id = {$DB_PREFIX}auth_info.uid")
                  ->field("{$DB_PREFIX}auth_mobile.*,{$DB_PREFIX}auth_idcard.*,{$DB_PREFIX}auth_info.*,{$DB_PREFIX}user.*")
                  ->find();
        if(!$authInfo){
            $this->error("用户信息未填写!");
        }
        $mobile_model = D("Auth_mobile");
        $mobile_info = $mobile_model->where(array('uid'=>$authInfo['uid']))->find();
        if($mobile_info){
            $authInfo['mobileAuthStatus'] = $mobile_info['status'];
            $authInfo['data'] = object_to_array(json_decode($authInfo['data']));
        }else{
            $authInfo['mobileAuthStatus'] = 0;
        }
        $this->assign('data',$authInfo);
        $this->display();
    }

    //调整额度及日息
    public function resetRate(){
        $id = I("post.id",0,'intval');
        $rate = I("post.rate");
        $quota= I("post.quota",0,'intval');
        if(!$id){
            $this->error("参数错误!");
        }
        $user_model = D("User");
        if(!$rate || !$quota){
            $this->error("用户额度及日息不规范!");
        }
        $min_money = nl_get_customConfig('min_money');
        if($quota <= $min_money){
            $this->error("用户额度必须大于系统预设最小额度!");
        }
        $status = $user_model->where(array('id'=>$id))->save(array('rate'=>$rate,'quota'=>$quota));
        if(!$status){
            $this->error("调整失败!");
        }
        $this->success("操作成功!");
    }



}