<?php
//认证中心
class AuthAction extends CommonAction{

	//认证中心
	public function index(){
		$user_info = getLoginUser();
		$status = array(
			'idcard'	=>		0,
			'info'		=>		0,
			'mobile'	=>		0
		);
		//身份信息
		$idcard_model = D("Auth_idcard");
		$idcard = $idcard_model->where(array('uid'=>$user_info['id']))->find();
		if($idcard){
			$t = 1;
			foreach ($idcard as $key => $value) {
				if(empty($value)){
					$t = 0;
				}
			}
			$status['idcard'] = $t;
		}
		//个人信息
		$info_model = D("Auth_info");
		$info = $info_model->where(array('uid'=>$user_info['id']))->find();
		if($info){
			$t = 1;
			foreach ($info as $key => $value) {
				if(empty($value) && $key != 'work_tel'){
					$t = 0;
				}
			}
			$status['info'] = $t;
		}
		//手机认证
		$mobile_model = D("Auth_mobile");
		$mobile = $mobile_model->where(array('uid'=>$user_info['id']))->find();
		if($mobile){
			$t = 1;
			foreach ($mobile as $key => $value) {
				if(empty($value)){
					$t = 0;
				}
			}
			$status['mobile'] = $t;
		}
		$this->assign('status',$status);
		$this->display();
	}

	//身份信息
	public function idcard(){
		$user_info = getLoginUser();
		$idcard_model = D("Auth_idcard");
		$idcard = $idcard_model->where(array('uid'=>$user_info['id']))->find();
		if(IS_POST){
			$name = I("post.name");
			$idcardNum = I("post.idcard");
			if(strlen($name) < 2){
				$this->error("请输入真实姓名!");
			}
			if(!isIdcard($idcardNum)){
				$this->error("请输入正确的身份证号码!");
			}
			$p_face = I("post.photo_face");
			$p_back = I("post.photo_back");
			$p = I("post.photo");
			if(strlen($p_face) == 0 || strlen($p_back) == 0 || strlen($p) == 0){
				$this->error("请上传必要照片!");
			}
			$arr = array(
				'name'		=>	$name,
				'idcard'	=>	$idcardNum,
				'photo_face'=>	$p_face,
				'photo_back'=>	$p_back,
				'photo'		=>	$p
			);
			if(!$idcard){
				$arr['uid'] = $user_info['id'];
				$status = $idcard_model->add($arr);
			}else{
				$status = $idcard_model->where(array('uid'=>$user_info['id']))->save($arr);
			}
			if(!$status){
				$this->error("保存数据失败!");
			}
			$this->success("操作成功!");
		}
		if(!$idcard)
			$idcard = array('name'=>'','idcard'=>'','photo_face'=>'','photo_back'=>'','photo'=>'');
		$this->assign('data',$idcard);
		$this->display();
	}

	//手机认证
	public function mobile(){
		$mobile_model = D("Auth_mobile");
		$user_info = getLoginUser();
		if(IS_POST){
			$mobile = I("post.phone");
			$passwd = I("post.passwd");
			if(!isMobileNum($mobile)){
				$this->error("手机号码不符合规范!");
			}
			if(strlen($passwd) != 6){
				$this->error("服务密码长度不规范!");
			}
			import('@.Class.Limu');
			$Limu = new Limu();
			$refer_obj = $Limu->ApiMobileGet($mobile,$passwd);
			if($refer_obj->code != '0010'){
				$this->error("提交认证失败:" . $refer_obj->code);
			}
			$arr = array(
				'uid'			=>		$user_info['id'],
				'phone'			=>		$mobile,
				'pass'			=>		$passwd,
				'refer'			=> 		1,
				'status'		=>		0,
				'data'			=>		json_encode(array()),
				'token'			=>		$refer_obj->token
			);
			$mobile_info = $mobile_model->where(array('uid'=>$user_info['id']))->find();
			if(!$mobile_info){
				$status = $mobile_model->add($arr);
			}else{
				$status = $mobile_model->where(array('uid'=>$user_info['id']))->save($arr);
			}
			if(!$status){
				$this->error("保存数据失败!");
			}
			$this->success("操作成功!");
		}
		$reset = I("get.reset",0,'intval');
		if($reset){
			$mobile_model->where(array('uid'=>$user_info['id']))->delete();
		}else{
			$mobile_info = $mobile_model->where(array('uid'=>$user_info['id']))->find();
		}
		if(!$mobile_info){
			$mobile_info = array('refer'=>0,'status'=>0);
		}
		$this->assign('data',$mobile_info);
		$this->display();
	}

	//个人信息
	public function info(){
		$info_model = D("Auth_info");
		$user_info = getLoginUser();
		$action = I("get.action",'info');
		//$this->action = $action;
		$info = $info_model->where(array('uid'=>$user_info['id']))->find();
		if(IS_POST){
			if(!$info){
				$_POST['uid'] = $user_info['id'];
				$status=$info_model->add($_POST);
			}else{
				$status=$info_model->where(array('uid'=>$user_info['id']))->save($_POST);
			}
			if(!$status){
				$this->error("保存信息失败!");
			}
			$this->success("操作成功!");
		}
		if(!$info){
			$info = array();
		}
		if($action == 'info'){
			$status = array(
				'work'		=>		1,
				'relation'	=>		1,
				'bank'		=>		1
			);
			$status_check_work = array(
				'work_industry','work_posts','work_name','work_city','work_address'
			);
			$status_check_relation = array(
				'people_relation_1','people_relation_2','people_name_1','people_name_2','people_tel_1','people_tel_2'
			);

			$status_check_bank = array(
				'bank_num','bank_name','bank_city','bank_phone'
			);
			foreach ($status_check_work as $value){
				if(empty($info[$value])){
					$status['work'] = 0;
					break;
				}
			}
			foreach ($status_check_bank as $value){
				if(empty($info[$value])){
					$status['bank'] = 0;
					break;
				}
			}
			foreach ($status_check_relation as $value){
				if(empty($info[$value])){
					$status['relation'] = 0;
					break;
				}
			}
			$this->assign('status',$status);
		}
		$this->assign('data',$info);
		$this->display('Auth/'.$action);
	}










}