<?php
/*

	接口回调

 */
class CallbackAction extends CommonAction{

		//手机运营商认证回调
		public function mobileAuth(){
			$code = I("request.code");
			$token = I("request.token");
			//调试信息
			$debug_str = 'code:'.$code.',token:'.$token.',';
			if($token){
				$mobile_model = D("Auth_mobile");
				$mobile_info = $mobile_model->where(array('token'=>$token))->find();
				if($mobile_info){
					$arr = array();
					if($code == '0000'){
						$arr['status'] = 1;
						import('@.Class.Limu');
						$Limu = new Limu();
						$mobile_obj = $Limu->ApiCommonGetResult($token,'mobile');
						if($mobile_obj->code == '0000'){
							$arr['data'] = json_encode(object_to_array($mobile_obj->data));
						}else{
							$arr['status'] = 2;
							$arr['data'] = json_encode(array());
						}
					}else{
						$arr['status'] = 2;
					}
					$status = $mobile_model->where(array('token'=>$token))->save($arr);
					$debug_str .= 'status:'.$arr['status'].',data:'.$arr['data'].',status:'.$status;
				}
			}
			file_put_contents(SITE_PATH."mobileAuth_".time().'.txt',$debug_str);
			echo "success";
		}


		//支付异步回调
		public function notifyPay(){
			import('@.Class.Alipay');
			$Alipay = new Alipay();
			$oid = $Alipay->notifyFun();
			if(!$oid){
				die("fail");
			}else{
				$loan_model = D("Loan");
				$info=$loan_model->where(array('oid'=>$oid))->find();
				if($info && !$info['payment_status']){
					//如果订单存在并且没有还款再处理
					$arr = array(
						'payment_status'	=>	1,
						'payment_time'		=>  time()
					);
					$status = $loan_model->where(array('oid'=>$oid))->save($arr);
					if(!$status)
						die("fail");
				}
				die("success");
			}
		}


		//支付同步回调
		public function returnPay(){
			import('@.Class.Alipay');
			$Alipay = new Alipay();
			$oid = $Alipay->returnFun();
			if(!$oid){
				$this->error("支付结果验证失败!",U('Index/index'));
			}
			$loan_model = D("Loan");
			$info=$loan_model->where(array('oid'=>$oid))->find();
			if($info && !$info['payment_status']){
				//如果订单存在并且没有还款再处理
				$arr = array(
					'payment_status'	=>	1,
					'payment_time'		=>  time()
				);
				$status = $loan_model->where(array('oid'=>$oid))->save($arr);
				if(!$status)
					$this->error("支付结果处理失败!",U('Loan/view',array('oid'=>$oid)));
			}
			$this->success("支付成功,正在跳转...",U('Loan/view',array('oid'=>$oid)));
		}


}