<?php
class CommonAction extends Action{

    public function _initialize(){
        //移动设备浏览且开启了手机独立主题，则切换模板
        $site_mobile = C('site_mobile');
        if (!empty($site_mobile) && ismobile() ) {
            //设置默认默认主题为 mobile
            C('DEFAULT_THEME','mobile');
        }
        $allow_module = array('Index','User','Common','Page','Callback');
        if(!in_array(MODULE_NAME,$allow_module)){
            if(!isLogin()){
                $this->redirect('User/login');
            }
        }
        /*
        
        	其他操作

         */

    }

    //设置前台用户登录状态
    protected function setLogin($arr = ''){
    	$session_name = nl_get_customConfig('loginsession');
    	if(empty($arr)){
    		session($session_name,null);
    		return true;
    	}
    	session($session_name,$arr);
    	return true;
    }

    //图形验证码
    public function verify(){
        import('ORG.Util.Image');
        Image::buildImageVerify(4,1);
    }


}