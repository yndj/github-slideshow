<?php
/*

	借款功能控制器

 */
class LoanAction extends CommonAction{

	//申请借款
	public function index(){
		$auth_status = R('Home/Index/checkAuth');
		if($auth_status != 3){
			$this->error("请先完成信息认证!",U('Auth/index'));
		}
		$money = I("post.money",0,'intval');
		$day = I("post.day",0,'intval');
		if(!$money || !$day){
			$this->error("参数错误!");
		}
		$user_info = getLoginUser();
		//判断是否有未审核订单
		$loan_model = D("Loan");
		$NoBowr = $loan_model->where(array('uid'=>$user_info['id'],'borrow_status'=>0))->count();
		if($NoBowr){
			$this->error("您有待审核订单,暂不能申请借款!");
		}
		//判断是否有未还款订单
		$NoBowr = $loan_model->where(array('uid'=>$user_info['id'],'borrow_status'=>1,'payment_status'=>0))->count();
		if($NoBowr){
			$this->error("您有未还款订单,暂不能申请借款!");
		}
		$min_money = nl_get_customConfig('min_money');
		$min_day = nl_get_customConfig('min_day');
		$max_day = nl_get_customConfig('max_day');
		$step_money=nl_get_customConfig('step_money');
		$money = intval($money / $step_money)*$step_money;
		if($money > $user_info['quota'] || $money < $min_money){
			$this->error("借款金额不符合规范!");
		}
		if($day > $max_day || $day < $min_day){
			$this->error("借款期限不符合规范!");
		}
		session("borrow",array('money'=>$money,'day'=>$day));
		$this->success("操作成功!",U('Loan/borrow'));
	}

	//借款确认
	public function borrow(){
		$user_info = getLoginUser();
		$borrow = session("borrow");
		$borrow['fee'] = ($user_info['rate']/100) * $borrow['money'] * $borrow['day'];
		$borrow['fee'] = Number_format($borrow['fee'],2,'.','');
		$borrow['money'] = Number_format($borrow['money'],2,'.','');
		$borrow['actual'] = Number_format($borrow['money']-$borrow['fee'],2,'.','');
		$info = M("Auth_info")->where(array('uid'=>$user_info['id']))->find();
		$borrow['bank'] = $info['bank_name'].' 尾号'.substr($info['bank_num'],-4);
		ksort($borrow);
		$str = '';
		foreach ($borrow as $key => $value) {
			$str .= $key.'='.$value;
		}
		$borrow['token'] = md5($str);
		if(IS_POST){
			$token = I("post.token");
			if(!$token || $token != $borrow['token']){
				$this->error("当前数据已过期,请刷新页面!");
			}
			$oid = mackOid();
			$arr = array(
				'uid'=>$user_info['id'],
				'oid'=>$oid,
				'money'=>$borrow['money'],
				'day'=>$borrow['day'],
				'fee'=>$borrow['fee'],
				'bankname'=>$info['bank_name'],
				'banknum'=>$info['bank_num'],
				'actual'=>$borrow['actual'],
				'create_time'=>time(),
				'borrow_status'=>0,
				'review_time'=>0,
				'review_note'=>'',
				'payment_status'=>0,
				'payment_time'=>0
			);
			$loan_model = D("Loan");
			$status = $loan_model->add($arr);
			if(!$status){
				$this->error("创建订单失败!");
			}
			session("borrow",null);
			$this->success("操作成功!",U('Loan/view',array('oid'=>$oid)));
		}
		$this->assign('borrow',$borrow);
		$this->display();
	}

	//借款记录列表
	public function lists(){
		$user_info = getLoginUser();
		$loan_model = D("Loan");
		$where = array('uid'=>$user_info['id']);
		import('ORG.Util.Page');
		$count = $loan_model->where($where)->count();
		$Page  = new Page($count,10);
		$Page->setConfig('theme',"%linkPage%");
		$show  = $Page->show();
		$lists = $loan_model->where($where)->limit($Page->firstRow.','.$Page->listRows)->order("id Desc")->select();
		$this->assign('data',$lists);
		$this->assign('page',$show);
		$this->display();
	}

	//借款记录查看
	public function view($oid=''){
		if(!$oid){
			$this->error("订单参数错误!");
		}
		$loan_model = D("Loan");
		$borrow = $loan_model->where(array('oid'=>$oid))->find();
		if(!$borrow){
			$this->error("订单不存在!");
		}
		$user_info = getLoginUser();
		if($borrow['uid'] != $user_info['id']){
			$this->error("您没有权限查看该订单!");
		}
		$info = M("Auth_info")->where(array('uid'=>$user_info['id']))->find();
		$borrow['bank'] = $info['bank_name'].' 尾号'.substr($info['bank_num'],-4);
		$sqdate = date("Y-m-d H:i:s",$borrow['review_time']);
		$borrow['expire_time'] = strtotime($sqdate." +".$borrow['day']." day");
		$borrow['is_expire'] = ($borrow['expire_time'] < time())?1:0;
		if($borrow['is_expire']){
			$borrow['expire_days'] = ceil((time()-$borrow['expire_time'])/86400);
		}
		$this->assign('borrow',$borrow);
		$this->display();
	}

	//订单还款
	public function payment($oid = ''){
		if(!$oid){
			$this->error("订单参数错误!");
		}
		$loan_model = D("Loan");
		$borrow = $loan_model->where(array('oid'=>$oid))->find();
		if(!$borrow){
			$this->error("订单不存在!");
		}
		$user_info = getLoginUser();
		if($borrow['uid'] != $user_info['id']){
			$this->error("您没有权限进行该操作!");
		}
		$out_trade_no = $oid;
		$subject = "借款订单:{$oid}还款";
		$total_amount = $borrow['money'];
		$timeout_express="5m";
		$body = '';
		import('@.Class.Alipay');
		$Alipay = new Alipay();
		$Alipay->pay($out_trade_no,$subject,$total_amount,$timeout_express,$body);
	}




}