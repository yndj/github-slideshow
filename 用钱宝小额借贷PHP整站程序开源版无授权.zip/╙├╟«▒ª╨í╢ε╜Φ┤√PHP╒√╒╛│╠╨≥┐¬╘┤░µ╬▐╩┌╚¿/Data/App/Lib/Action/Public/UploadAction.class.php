<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/2/18 0018
 * Time: 21:48
 *  公共文件上传控制器
 */
class UploadAction extends Action{

        public function index(){
            $file_name = empty($_GET['n'])?'file':$_GET['n'];
            if($file_name && is_uploaded_file($_FILES[$file_name]["tmp_name"])){
                import('ORG.Net.UploadFile');
                $upload = new UploadFile();
                $maxSize = C('upload_maxsize');
                $maxSize = empty($maxSize)?2048:intval($maxSize);
                $extensions = C('upload_extensions');
                $extensions = empty($extensions)?'':$extensions;
                $tmp = explode(',',$extensions);
                $exts = array();
                foreach($tmp as $val){
                    $exts[] = $val;
                }
                $upload->maxSize  = intval($maxSize) * 1024;//字节单位
                $upload->allowExts  = $exts;
                $upload->savePath =  SITE_PATH.'Upload/';//设置附件上传目录
                $upload->uploadReplace = true;
                $upload->autoSub = true;
                $upload->subType = 'date';
                $upload->dateFormat = 'Y_m_d';
                if(!$upload->upload()) {
                    //上传错误提示错误信息
                    $msg = $upload->getErrorMsg();
                }else{
                    //上传成功 获取上传文件信息
                    $info =  $upload->getUploadFileInfo();
                    $site_url = C('site_url');
                    for($i=0;$i<count($info);$i++){
                        $info[$i]['url'] = $site_url.'Upload/'.$info[$i]['savename'];
                    }
                    $msg = "success";
                }

            }else{
                $msg = "没有选择文件!";
            }
            if($msg == 'success'){
                $this->success($info,'',true);
            }
            $this->error($msg,'',true);

        }




}