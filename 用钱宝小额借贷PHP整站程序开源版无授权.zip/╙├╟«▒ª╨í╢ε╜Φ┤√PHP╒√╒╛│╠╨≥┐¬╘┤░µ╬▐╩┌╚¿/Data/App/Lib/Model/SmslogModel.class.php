<?php
/*
 *  短信发送记录模型
 * */
class SmslogModel extends Model{
    protected $tableName = 'smslog';

    /*
		检查手机号当日发送次数是否超过限制
    	mobile:手机号
     */
    public function checkUp($mobile=''){
		$day_time = strtotime(date("Y-m-d"));
		$arr = array('mobile'=>$mobile,'status'=>1,'create_time'=>array('GT',$day_time));
		$r = $this->where($arr)->count();
		$dcount = nl_get_customConfig('smsdcount');
		$dcount = empty($dcount)?4:$dcount;
		if($r >= $dcount){
			return false;
		}
		return true;
    }

    /*
    	生成短信验证码内容并发送
		type:发送类型(如reg,findpass)
     */
    public function sendCode($mobile,$type){
    	$smstpl = array(
    		'reg'=>nl_get_customConfig('regsmstpl'),
            'findpass'=>nl_get_customConfig('findpasstpl')
    	);
    	$code = strtoupper(chr(rand(97, 122))).rand(0,9).rand(0,9).rand(0,9);
    	$content = $smstpl[$type];
    	$content = str_replace('{code}',$code,$content);
    	//写入短信记录
    	import('@.Class.Sms');
    	$sms = new Sms();
    	$r = $sms->sendSms($mobile,$content);
    	if($r == '0')
    		$status = 1;
    	else
    		$status = 0;
		$arr = array(
			'type'=>$type,
			'code'=>$code,
			'mobile'=>$mobile,
			'create_time'=>time(),
			'status'=>$status,
            'check' => 0
		);
		$this->add($arr);
		return $r;
    }

    /*
        检查验证码
        mobile:手机号
        code:验证码
     */
    public function checkCode($mobile,$code,$type){
        $r = $this->where(array('mobile'=>$mobile,'code'=>$code,'type'=>$type,'check'=>0))->order("create_time Desc")->find();
        if(!$r){
            return false;
        }
        $this->where(array('mobile'=>$mobile,'code'=>$code,'type'=>$type))->save(array('check'=>1));
        return $r;  
    }



}